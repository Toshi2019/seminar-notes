%%Title: dc_header_02.pdf
%%Creator: extractbb 20220710
%%BoundingBox: 0 635 594 790
%%CreationDate: Fri Feb 13 22:15:15 2026

